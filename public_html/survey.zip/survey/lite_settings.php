<?

$email_to ="design@optimist.co.in,supriya@optimist.co.in "; 
$email_subject = "Survey "; // email subject line
$thankyou = "../thank-you.html"; // thank you page

?>



